package edu.ncsu.mavenbot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.ncsu.mavenbot.model.GitAdapterModel;
import edu.ncsu.mavenbot.model.ResponseModel;
import edu.ncsu.mavenbot.service.GitAdapterService;
import edu.ncsu.mavenbot.service.MavenAdapterService;

@Controller
@RequestMapping("/decisioncontroller")
public class DecisionMakingController {

	GitAdapterService gitAdapterService;
	MavenAdapterService mavenAdapterService;
	
	@RequestMapping(value="/showcommand/{command}", method = RequestMethod.GET)
	public String getMovie(@PathVariable String command, ModelMap model) {

		model.addAttribute("command", command);
		return "commandDetails";

	}
	
	@RequestMapping(value="executecommand/{command}", method = RequestMethod.GET)
	public @ResponseBody ResponseModel executeCommand(@PathVariable String command) {

		System.out.println("In a controller method....");
		
		if (command!=null) {
			if(command.equalsIgnoreCase("ls"))
			{
				return gitAdapterService.listRepo();			
			}
			else if (command.startsWith("cp"))
			{
				String newDirectory = command.trim().split("_")[1];
				return gitAdapterService.changeRepo(newDirectory);
			}
			else if (command.startsWith("ld"))
			{
				return mavenAdapterService.Run();
			}
			else
			{
				return new ResponseModel();
			}
		}
		else
		{
			return new ResponseModel();
		}
	}

	public void setGitAdapterService(GitAdapterService gitAdapterService) {
		this.gitAdapterService = gitAdapterService;
	}

	public void setMavenAdapterService(MavenAdapterService mavenAdapterService) {
		this.mavenAdapterService = mavenAdapterService;
	}
	
	

}
