package edu.ncsu.mavenbot.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import edu.ncsu.mavenbot.model.ResponseModel;

public class MavenAdapterService {
	
		ResponseModel responseModel;
		//the name of the directory that contains the project to look for updates
		String projectLocation = "D:/Projects/Git/MavenBot/BuildSlackers/TestProjectID";
		
		//the name of the directory to copy the project to to look for updates
		String projectUpdateLocation = "D:/BS-Mock/local/Test";
		
		private List<Dependency> dependencyList;
		
		
		public MavenAdapterService() {
			dependencyList = new ArrayList<Dependency>();
		}
		
		public ResponseModel Run() {
			//wipe previous list
			dependencyList.clear();
			this.MakeDirectory();
			this.CopyProject();
			this.FindDependencies();
			this.FindUpdatesForDependencies();
			this.DeleteProject();
			StringBuilder listDeps = new StringBuilder();
			for (int i = 0; i < dependencyList.size(); i++) {
				Dependency curr = dependencyList.get(i);
				listDeps.append(curr.groupID + ":" + curr.artifactID + ":" + curr.currVersion + ":" + curr.newerVersions);
				listDeps.append("\n");
			}
			
			System.out.println("Printing Dependancies : ");
			System.out.println(listDeps.toString());
			responseModel.setResponseMessage(listDeps.toString());
			
			return responseModel;
		}
		
		public String UpdateDependencyToLatestGoodVersion(String dependencyGroup, String artifactID) {
			//need to have the dependencyList be the same (or have them pass in the version as well)
			//assuming dependencyList is the same, just update til it reaches maxVersion
			//need to make these updates on the project repo, instead of the fake, copy one
			//need to find the Dependency it is talking about
			Dependency dep = new Dependency();
			dep.artifactID = artifactID;
			dep.groupID = dependencyGroup;
			int index = dependencyList.indexOf(dep);
			String versionToUpdateTo = "";
			if (index != -1) {
				versionToUpdateTo = dependencyList.get(index).maxUpdateableVersion;
			}
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c",
					"cd " + projectLocation + " && mvn versions:use-next-releases -Dincludes=" + 
					dependencyGroup + ":" + artifactID);
			builder.redirectErrorStream(true);
			boolean continueUpdate = true;
			while (continueUpdate) {
				try {
					Process p = builder.start();
					BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
					String line;
					String newVersion = "";
					while (true) {
						line = r.readLine();
						if (line == null) {
							break;
						}
						if (line.contains("Updated")) {
							//know that a dependency has a newer version
							String[] parts = line.split("\\s+");
							newVersion = parts[parts.length - 1]; //last one is the new version
							if (newVersion.equals(versionToUpdateTo)) {
								continueUpdate = false;
							}
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return "Update Successful";
		}
		
		//will just run, and return the dependency group:artifact id:currversion:latestupdateableversion
		public String FindLatestGoodVersions() {
			//need to update one at a time -> find list of current dependencies (then wipe it)
			dependencyList.clear();
			this.MakeDirectory();
			this.CopyProject();
			this.FindDependencies();
			//now have list of the dependencies
			//get the first of them, and until update doesn't work anymore, update->compile->test
			//if all those pass, if version higher than maxupdateableversion, set new maxupdateableversion
			int count = dependencyList.size();
			for(int i = 0; i < count; i++) {
				//set maxupdateable version to current one
				Dependency currDep = dependencyList.get(i);
				dependencyList.remove(i); //have to remove, so can add it back later
				currDep.maxUpdateableVersion = currDep.currVersion;
				boolean updateAvailable = true;
				while (updateAvailable) {
					ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", 
							"cd " + projectUpdateLocation + " && mvn versions:use-next-releases -Dincludes=" + 
							currDep.groupID + ":" + currDep.artifactID);
					builder.redirectErrorStream(true);
					try {
						//whether or not there was an updated version last time,
						//set to true, so we always try at least once
						updateAvailable = false;
						Process p = builder.start();
						BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
						String line;
						String newVersion = "";
						while (true) {
							line = r.readLine();
							if (line == null) {
								break;
							}
							if (line.contains("Updated")) {
								updateAvailable = true;
								//know that a dependency has a newer version
								String[] parts = line.split("\\s+");
								newVersion = parts[parts.length - 1]; //last one is the new version
							}
						}
						//now need to compile, and test
						if (CompileProject() && TestsPass() && updateAvailable) {
							//set version update
							currDep.maxUpdateableVersion = newVersion;
						}
					} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
				}
				//no more updates available, so add in the maxupdateable version
				dependencyList.add(i, currDep);
				//now need to reset it to what it was before -> need to delete currProject and make new copy
				this.DeleteProject();
				this.MakeDirectory();
				this.CopyProject();
			}
			//have gone through all of them, need to return the list
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < dependencyList.size(); i++) {
				Dependency curr = dependencyList.get(i);
				if (!curr.maxUpdateableVersion.equals(curr.currVersion)) {
					sb.append(curr.groupID + ":" + curr.artifactID + ":" + curr.currVersion + ":" + curr.maxUpdateableVersion);
					sb.append("\n");
				}
			}
			this.DeleteProject();
			return sb.toString();
			
		}
		
		private boolean TestsPass() {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", 
					"/c", "cd " + projectUpdateLocation + "&& mvn test");
			try {
				Process p = builder.start();
				builder.redirectErrorStream(true);
				return true;
				//for the mocking, return true
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
		
		private boolean CompileProject() {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", 
					"/c", "cd " + projectUpdateLocation + " && mvn compile");
			builder.redirectErrorStream(true);
			try {
				Process p = builder.start();
				//for now just return true
				return true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
		
		private void FindUpdatesForDependencies() {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", 
					"cd " + projectUpdateLocation + " && mvn versions:use-next-releases");
			builder.redirectErrorStream(true);
			try {
				//whether or not there was an updated version last time,
				//set to true, so we always try at least once
				boolean updateAvailable = true;
				while (updateAvailable) {
					updateAvailable = false;
					Process p = builder.start();
					BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
					String line;
					while (true) {
						line = r.readLine();
						if (line == null) {
							break;
						}
						if (line.contains("Updated")) {
							updateAvailable = true;
							//know that a dependency has a newer version
							String[] parts = line.split("\\s+");
							String depPart = parts[2];
							String[] depSplit = depPart.split(":");
							String depGroup = depSplit[0];
							String depArtifact = depSplit[1];
							String depVersion = depSplit[3];
							String updatedVersion = parts[parts.length - 1]; //last one is the new version
							Dependency currDependency = new Dependency();
							currDependency.groupID = depGroup;
							currDependency.artifactID = depArtifact;
							int storedIndex = dependencyList.indexOf(currDependency);
							if (storedIndex != -1) {
								dependencyList.get(storedIndex).newerVersions.add(updatedVersion);
							}
						}
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		private void FindDependencies() {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", 
					"cd " + projectUpdateLocation + " && mvn -o dependency:list");
			builder.redirectErrorStream(true);
			try {
				Process p = builder.start();
				BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
				String line;
				while (true) {
					line = r.readLine();
					if (line == null) {
						break;
					}
					if (line.contains("The following files have been resolved:")) {
						//all dependencies are guaranteed to have a colon
						line = r.readLine();
						while (line.contains(":")) {
							//split on whitespace
							String[] parts = line.split("\\s+");
							//take the second one
							String dependency = parts[1];
							//split on colon
							String[] dependencyParts = dependency.split(":");
							Dependency dep = new Dependency();
							dep.groupID = dependencyParts[0];
							dep.artifactID = dependencyParts[1];
							dep.currVersion= dependencyParts[3];
							dependencyList.add(dep);
							line = r.readLine();
						}
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		private void MakeDirectory() {
			File projectUpdateDir = new File(projectUpdateLocation);
			if (!projectUpdateDir.exists()) {
				projectUpdateDir.mkdir();
			}
			/*ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", 
					"mkdir " + projectUpdateLocation);*/
			try {
				//Process p = builder.start();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		private void CopyProject() {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", 
					"/c", "xcopy " + projectLocation + " " + projectUpdateLocation + " /e");
			try {
				Process p = builder.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
			/**
			 * Performs cleanup, so that at the end we delete the copy of the project
			 */
		private void DeleteProject() {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", 
					"/c", "rmdir " + projectUpdateLocation + " /s /q");
			try {
				Process p = builder.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		}
		
		private class Dependency {
			public String groupID;
			public String artifactID;
			public String currVersion;
			public List<String> newerVersions = new ArrayList<String>();
			public String maxUpdateableVersion;
			
			public boolean equals(Object o) {
				Dependency other = (Dependency) o;
				return this.groupID.equals(other.groupID) && this.artifactID.equals(other.artifactID);
			}
		}

		
		public ResponseModel getResponseModel() {
			return responseModel;
		}

		public void setResponseModel(ResponseModel responseModel) {
			this.responseModel = responseModel;
		}

		public String getProjectLocation() {
			return projectLocation;
		}

		public void setProjectLocation(String projectLocation) {
			projectLocation = projectLocation;
		}

		public String getProjectUpdateLocation() {
			return projectUpdateLocation;
		}

		public void setProjectUpdateLocation(String projectUpdateLocation) {
			projectUpdateLocation = projectUpdateLocation;
		}

		public List<Dependency> getDependencyList() {
			return dependencyList;
		}

		public void setDependencyList(List<Dependency> dependencyList) {
			this.dependencyList = dependencyList;
		}
		
		

}
