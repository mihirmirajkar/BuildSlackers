package edu.ncsu.mavenbot.model;

public class MavenAdapterModel {

	private String responseMessage;
	private String errorMessage;
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "MavenAdaptorModel [responseMessage=" + responseMessage + ", errorMessage=" + errorMessage + "]";
	}
	
	
}
