package edu.ncsu.mavenbot.model;

public class ResponseModel {

	private String errorCode;
	private String errorMessage;
	private boolean isSuccessful;
	private String responseMessage;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public boolean isSuccessful() {
		return isSuccessful;
	}
	public void setSuccessful(boolean isSuccessful) {
		this.isSuccessful = isSuccessful;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "ResponseModel [errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", isSuccessful="
				+ isSuccessful + ", responseMessage=" + responseMessage + "]";
	}
	
	
}
